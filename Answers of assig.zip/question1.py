
startingNumber = int(input("Enter the Starting the number: "))
endingNumber = int(input("Enter the ending number: "))
allPrimes = 0
for num in range (startingNumber, endingNumber+1):
 if num>1:
  for i in range (2,num):
   if num % i==0:
    break
  else: allPrimes += 1
def  count_prime(num,startingNumber,endingNumber):
  count_prime= 0
  for x in num:
    if startingNumber <= x <= endingNumber:
      count_prime += 1
print(allPrimes)
