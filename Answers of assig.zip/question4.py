
import math
number = int(input("Enter the number: "))
Guthrie = [number]
while number > 1:
#     print(number)
    if number % 2 == 0:
        number = number /2
    else:
        number = (number * 3) + 1
    Guthrie.append(math.trunc(number))   
print(Guthrie)    
