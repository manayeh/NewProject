listsOfString = []
number = int(input("Enter the number: "))
text = str(number)
listsOfString = [int(s) for s in text]
print(listsOfString)
 
