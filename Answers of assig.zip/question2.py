
# number = [1]
# number = [2]
number = [1, 2, 3, 4]
# number = [1, 1, 1, 1, 1, 1, 2]
# number = [2, 12, 12, 4, 6, 8, 11]
# number = [2, 12, 12, 4, 6, 8, 11]
# number = [-2, -4, -6, -8, -11]
containOdd = False
maxIsEven = False
EveryOddGreaterThanEven = True
maxNumber = max(number)
if maxNumber % 2 == 0:
     maxIsEven = True
for n in number:
    if n % 2 != 0:
         containOdd = True
p = [num for num in number if (num != maxNumber) & (num % 2 == 0)]
q = [num for num in number if (num != maxNumber) & (num % 2 != 0)]
for f in q:
    for m in p:
        if f<m:
            EveryOddGreaterThanEven = False
if(containOdd == True & maxIsEven == True & EveryOddGreaterThanEven == True):
    print(1)
else:
    print(0)
