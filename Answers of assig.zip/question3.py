num = int(input("insert the number: "))

if num > 1:
    for i in range(2, num):
        if (num%i)==0:
            print("NOT A PRIME NUMBER")
            break
    else:
        if(num%10 == 9):
            while True:
                num = num + 1;
                for i in range(2, num):
                    if (num%i)==0:
                        break
                else:
                    if(num%10==9):
                        print("A PORCUPINE NUMBER.")
                        break
                    else:
                        print("PRIME BUT NOT PORCUPINE.")
else:
    print("THE NUMBER IS LESS THAN ZERO")